package co.com.vass.bank.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import co.com.vass.bank.vo.Administrator;
import co.com.vass.bank.vo.Advisor;
import co.com.vass.bank.vo.City;
import co.com.vass.bank.vo.Costumer;
import co.com.vass.bank.vo.Departament;
import co.com.vass.bank.vo.User;

public class UserDAO {
	
////...::::FUNCIONALIDAD LOGIN(Costumer:3, Advisor: 2, Administrator: 1)::::...
	

//:::ADMINISTRATOR:::
	
	public boolean login(User user) {
		boolean usuarioexiste = false;
		Configuration configuration = new Configuration();

		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		String queryString = "from User where username = :username and password= :password and idroles= 1";
		Query<?> query = session.createQuery(queryString);

		query.setParameter("username", user.getUsername());
		query.setParameter("password", user.getPassword());
		Object queryResult = query.uniqueResult();
		User user2 = (User) queryResult;

		System.out.println(user2);
		session.getTransaction().commit();
		session.close();

		if (user2 == null)
			usuarioexiste = false;
		else
			usuarioexiste = true;

		return usuarioexiste;
	}
	
	
//:::ADVISOR:::
	
	public boolean login2(User user) {
		boolean usuarioexiste = false;
		Configuration configuration = new Configuration();

		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		String queryString = "from User where username = :username and password= :password and idroles= 2";
		Query<?> query = session.createQuery(queryString);

		query.setParameter("username", user.getUsername());
		query.setParameter("password", user.getPassword());
		Object queryResult = query.uniqueResult();
		User user2 = (User) queryResult;

		System.out.println(user2);
		session.getTransaction().commit();
		session.close();

		if (user2 == null)
			usuarioexiste = false;
		else
			usuarioexiste = true;

		return usuarioexiste;
	}
	
//:::COSTUMER:::
	
	public boolean login3(User user) {
		boolean usuarioexiste = false;
		Configuration configuration = new Configuration();

		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		String queryString = "from User where username = :username and password= :password and idroles= 3";
		Query<?> query = session.createQuery(queryString);

		query.setParameter("username", user.getUsername());
		query.setParameter("password", user.getPassword());
		Object queryResult = query.uniqueResult();
		User user2 = (User) queryResult;

		System.out.println(user2);
		session.getTransaction().commit();
		session.close();

		if (user2 == null)
			usuarioexiste = false;
		else
			usuarioexiste = true;

		return usuarioexiste;
	}
	
	
	
////...::::FUNCIONALIDAD REGISTER(Costumer:3, Advisor: 2, Administrator: 3)::::...	

	
//:::COSTUMER:::
	
	public boolean Register(User user, Costumer costumer) {
		boolean userRegister = false;
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.getCurrentSession();
//		try {

			session.beginTransaction();
			
			user.setIdroles("3");
			user.setIdUser(0);
			System.out.println("Impresion antes de guardar"+user);
			session.save(user);			
			System.out.println("Impresion despues de guardar"+user);
			
			System.out.println("Impresion antes de guardar"+costumer);
			costumer.setIdUser(user.getIdUser());
			System.out.println("Impresion antes de guardar - setiado "+costumer);
			session.save(costumer);
			System.out.println("Impresion de customer despues de guardar"+costumer);

			session.getTransaction().commit();
			session.close();
			userRegister = true;
//		} catch (Exception x) {
//
//			userRegister = false;
//		}

		return userRegister;
			}
	

	
//:::ADMINISTRATOR:::
	
		public boolean Registeradm(User user, Administrator administrator) {
		boolean admRegister = false;
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		user.setIdroles("1");
		user.setIdUser(0);
		System.out.println("Impresion antes de guardar"+user);
		session.save(user);			
		System.out.println("Impresion despues de guardar"+user);
		
		System.out.println("Impresion antes de guardar"+administrator);
		administrator.setIdUser(user.getIdUser());
		System.out.println("Impresion antes de guardar - setiado "+administrator);
		session.save(administrator);
		System.out.println("Impresion de customer despues de guardar"+administrator);

		session.getTransaction().commit();
		session.close();
		admRegister = true;
		return admRegister;

		
	}
		
		
//:::ADVISOR:::

		public boolean Registeradv(User user, Advisor advisor) {
		boolean advRegister = false;
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		user.setIdroles("2");
		user.setIdUser(0);
		System.out.println("Impresion antes de guardar"+user);
		session.save(user);			
		System.out.println("Impresion despues de guardar"+user);
		
		System.out.println("Impresion antes de guardar"+advisor);
		advisor.setIdUser(user.getIdUser());
		System.out.println("Impresion antes de guardar - setiado "+advisor);
		session.save(advisor);
		System.out.println("Impresion de customer despues de guardar"+advisor);

		session.getTransaction().commit();
		session.close();
		advRegister = true;
		return advRegister;

		}
	

////...::::FUNCIONALIDAD LIST(Advisor: 2, Administrator: 1)::::...	
	
	public List<Costumer> lista() {
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		String queryString = "from Costumer";
		Query query = session.createQuery(queryString);
		List<Costumer> userList = query.list();
		session.getTransaction().commit();
		session.close();
		for (Costumer cost : userList) {
			System.out.println(cost.toString());
		}
		return userList;

	}
	
	public List<Advisor> listaadv() {
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.getCurrentSession();
		session.beginTransaction();
		String queryString = "from Costumer";
		Query query = session.createQuery(queryString);
		List<Advisor> userListadv = query.list();
		session.getTransaction().commit();
		session.close();
		for (Advisor cost : userListadv) {
			System.out.println(cost.toString());
		}
		return userListadv;

	}
	


////...::::FUNCIONALIDAD SHOW(Costumer:3, Advisor: 2, Administrator: 1)::::... 
	
	public Costumer showuser(String idcostumer) {
		try {
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.getCurrentSession();
			session.beginTransaction();
			String queryString = "from Costumer where idcostumer= :idcostumer";

			Query query = session.createQuery(queryString);
			Integer id = Integer.parseInt(idcostumer);
			query.setParameter("idcostumer", id);

			Costumer costumer = new Costumer();
			costumer = (Costumer) query.uniqueResult();
			session.getTransaction().commit();


			System.out.println(costumer.toString());

			return costumer;

		} catch (Exception e) {
			System.out.println(e);
			return null;
		}

	}
	
	public Advisor showuseradv(String idadvisor) {
		try {
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.getCurrentSession();
			session.beginTransaction();
			String queryString = "from Costumer where idcostumer= :idcostumer";

			Query query = session.createQuery(queryString);
			Integer id = Integer.parseInt(idadvisor);
			query.setParameter("idcostumer", id);

			Advisor advisor = new Advisor();
			advisor = (Advisor) query.uniqueResult();
			session.getTransaction().commit();


			System.out.println(advisor.toString());

			return advisor;

		} catch (Exception e) {
			System.out.println(e);
			return null;
		}

	}
	
////...::::FUNCIONALIDAD UPDATE(Costumer:3, Advisor: 2, Administrator: 1)::::...

	public boolean updateuser(Costumer costumer) {

		boolean usersRegister = false;

		try {
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.getCurrentSession();
			session.beginTransaction();
			System.out.println(costumer);
			session.update(costumer);
			session.getTransaction().commit();
			

			session.close();
			return  true;
		} catch (Exception x) {

			System.out.println(x);
			return usersRegister;
		}
		
	}
	
	public boolean updateuseradv(Advisor advisor) {

			boolean usersRegister = false;

			try {
				SessionFactory factory = new Configuration().configure().buildSessionFactory();
				Session session = factory.getCurrentSession();
				session.beginTransaction();
				System.out.println(advisor);
				session.update(advisor);
				session.getTransaction().commit();
				

				session.close();
				return  true;
			} catch (Exception x) {

				System.out.println(x);
				return usersRegister;
			}
		
//...::::FUNCIONALIDAD DELETE(Advisor: 2, Administrator: 1)::::...
	}
	public Costumer deleuser(int fk_customer_user) {
		
		try {
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.getCurrentSession();
			session.beginTransaction();
			System.out.println(":v");
			String queryUser = "from Costumer where idcostumer= :idcostumer";
			Query cus = session.createQuery(queryUser);
			cus.setParameter("idcostumer", fk_customer_user);
			Costumer costumer = (Costumer) cus.uniqueResult();
			System.out.println("1");
			System.out.println(costumer);
			System.out.println("2");
			session.delete(costumer);
			session.getTransaction().commit();
			session.close();
			System.out.println("3");
			return costumer;
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			return null;
		}
	}
	
	public Costumer deleuseradv(int fk_advisor_user) {
		
		try {
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.getCurrentSession();
			session.beginTransaction();
			System.out.println(":v");
			String queryUser = "from Costumer where idcostumer= :idcostumer";
			Query cus = session.createQuery(queryUser);
			cus.setParameter("idcostumer", fk_advisor_user);
			Costumer costumer = (Costumer) cus.uniqueResult();
			System.out.println("1");
			System.out.println(costumer);
			System.out.println("2");
			session.delete(costumer);
			session.getTransaction().commit();
			session.close();
			System.out.println("3");
			return costumer;
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			return null;
		}
	}
		public List<Departament> listadepart(String iddepartament) {
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.getCurrentSession();
			session.beginTransaction();
			System.out.println("1");
			String queryString = "from Departament";
			Query query = session.createQuery(queryString);
			System.out.println("2");
			List<Departament> departament = query.list();
			System.out.println("3");
			session.getTransaction().commit();
			System.out.println("4");
			session.close();
			for (Departament deprt : departament) {
				System.out.println(deprt.toString());
			}
			return null;

	}
		public List<City> listacity(String iddepartament) {
			try {
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.getCurrentSession();
			session.beginTransaction();
			String queryString = "from City where iddepartment = :iddepartment";
			Query query = session.createQuery(queryString);
			query.setParameter("iddepartment", Integer.parseInt(iddepartament));
			List<City> city = query.list();
			session.getTransaction().commit();
			session.close();
			for (City cit : city) {
				System.out.println(cit.toString());
				
			}
			return city;
			} catch (Exception w) {
				System.out.println(w);
			}
			return null;
		}
	
		
		
	}
	
	

		
		
		
		


	
	
