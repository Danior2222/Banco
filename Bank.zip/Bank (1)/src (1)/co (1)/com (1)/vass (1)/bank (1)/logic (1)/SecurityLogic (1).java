package co.com.vass.bank.logic;

import java.util.List;

import co.com.vass.bank.dao.UserDAO;
import co.com.vass.bank.vo.Administrator;
import co.com.vass.bank.vo.Advisor;
import co.com.vass.bank.vo.City;
import co.com.vass.bank.vo.Costumer;
import co.com.vass.bank.vo.Departament;
import co.com.vass.bank.vo.User;

public class SecurityLogic {

	public boolean login(User user) {

		UserDAO dao = new UserDAO();
		boolean r = dao.login(user);
		return r;

	}
	public boolean loginadv(User user) {

		UserDAO dao = new UserDAO();
		boolean a = dao.login2(user);
		return a;

	}
	public boolean logincost(User user) {

		UserDAO dao = new UserDAO();
		boolean l	 = dao.login3(user);
		return l;

	}

	public boolean register(User user, Costumer costumer) {

		UserDAO dao1 = new UserDAO();
		boolean a = dao1.Register(user, costumer);
		return a;
	}
	public boolean registeradvi(User user, Advisor advisor) {

		UserDAO dao1 = new UserDAO();
		boolean a = dao1.Registeradv(user, advisor);
		return a;
	}
	public boolean registeradmin(User user, Administrator administrator) {

		UserDAO dao1 = new UserDAO();
		boolean a = dao1.Registeradm(user, administrator);
		return a;
	}

	public List<Costumer> lista() {
		UserDAO dao2 = new UserDAO();
		List<Costumer> userList = dao2.lista();
		return userList;

	}
	
	public List<Advisor> listaadv() {
		UserDAO dao2 = new UserDAO();
		List<Advisor> userListadv = dao2.listaadv();
		return userListadv;

	}

	public Costumer showus(String idcostumer) {
		UserDAO dao3 = new UserDAO();
		Costumer b = dao3.showuser(idcostumer);
		return b;

	}
	
	public boolean Upduser(Costumer costumer) {
		UserDAO dao4 = new UserDAO();
		boolean c = dao4.updateuser(costumer);
		return c;
	
	}
	public Costumer deluser(int fk_customer_user) {
		UserDAO dao2 = new UserDAO();
		Costumer use = dao2.deleuser(fk_customer_user);
		
		return use;
	}
		public List<Departament> listadprt(String iddepartament){
			UserDAO dao2 = new UserDAO();
			List<Departament> dept = dao2.listadepart(iddepartament);		
			return dept;
			
		}
		public List<City> listact(String iddepartament){
			UserDAO dao2 = new UserDAO();
			List<City> citty = dao2.listacity(iddepartament);		
			return citty;
			
		
		
		
	}
	
	}

