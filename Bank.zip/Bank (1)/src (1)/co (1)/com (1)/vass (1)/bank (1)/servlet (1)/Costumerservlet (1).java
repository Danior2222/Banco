package co.com.vass.bank.servlet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.com.vass.bank.logic.SecurityLogic;
import co.com.vass.bank.vo.Costumer;
import co.com.vass.bank.vo.User;

/**
 * Servlet implementation class Costumer
 */
@WebServlet("/Costumerservlet")
public class Costumerservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Costumerservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String tyId = request.getParameter("tyId");		
		String identification= request.getParameter("identification");
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
		
		//Formateo de Fecha
		Date birthDate = null;	
		try {
			birthDate = dateFormat.parse(request.getParameter("birthDate"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		String email = request.getParameter("email");	
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String ciudad = request.getParameter("city");
		
		Costumer costumer = new Costumer();
		User user2 = new User();
		
		user2.setUsername(username);
		user2.setPassword(password);
			
		costumer.setTyId(tyId);
		costumer.setIdentification(identification);
		costumer.setFirstName(firstName);
		costumer.setLastName(lastName);
		costumer.setPhone(phone);
		costumer.setAddress(address);
		costumer.setBirthDate(birthDate);
		costumer.setEmail(email);
		costumer.setCiudad(ciudad);
		costumer.setIdUser(0);
		costumer.setIddepartament(0);
		costumer.setIdadvisor(0);
		costumer.setIdadministrator(0);
		costumer.setIdroles(3);	
		costumer.setFk_customer_user(0);
		
		SecurityLogic sec = new SecurityLogic();
		boolean ok = sec.register(user2, costumer);
		
		
		SecurityLogic sec1 = new SecurityLogic();
		List<Costumer> userList = sec1.lista();

		request.setAttribute("listCustomers", userList);
		
		doGet(request, response);
	}

}
