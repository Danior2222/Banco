package co.com.vass.bank.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.com.vass.bank.logic.SecurityLogic;
import co.com.vass.bank.vo.Advisor;
import co.com.vass.bank.vo.Costumer;
import co.com.vass.bank.vo.User;

/**
 * Servlet implementation class Regadvservlet
 */
@WebServlet("/Regadvservlet")
public class Regadvservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Regadvservlet() {
    	   super();
           // TODO Auto-generated constructor stub
       }

   	/**
   	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   	 */
   	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   		// TODO Auto-generated method stub
   		
   		response.getWriter().append("Served at: ").append(request.getContextPath());
   	}

   	/**
   	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
   	 */
   	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   		// TODO Auto-generated method stub
   		//doGet(request, response);
   		String identificationadv= request.getParameter("identificationadv");
   		String firstnameadv = request.getParameter("firstnameadv");
   		String lastnameadv = request.getParameter("lastnameadv");
   		String phoneadv = request.getParameter("phoneadv");
   		String emailadv = request.getParameter("emailadv");	
   		String username = request.getParameter("username");
   		String password = request.getParameter("password");
   		
   		
   		Advisor advisor = new Advisor();
   		User user2 = new User();
   		
   		user2.setUsername(username);
   		user2.setPassword(password);
   			
   		
   		advisor.setIdentificationadv(identificationadv);
   		advisor.setFirstnameadv(firstnameadv);
   		advisor.setLastnameadv(lastnameadv);
   		advisor.setPhoneadv(phoneadv);
   		advisor.setEmailadv(emailadv);
   		advisor.setIdUser(0);
   		advisor.setIdadvisor(0);
   		advisor.setIdadministrator(0);
   		advisor.setIdroles(2);	
   		advisor.setFk_advisor_user(0);
   		
   		SecurityLogic sec = new SecurityLogic();
   		boolean ok = sec.registeradvi(user2, advisor);
   		
   		
   		SecurityLogic sec1 = new SecurityLogic();
   		List<Advisor> userListadv = sec1.listaadv();

   		request.setAttribute("listAdvisor", userListadv);
   		
   		doGet(request, response);
   	}

   }
