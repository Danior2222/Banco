package co.com.vass.bank.vo;

public class Advisor {
	private int idadvisor;
	private String identificationadv;
	private String phoneadv;
	private String firstnameadv;
	private String lastnameadv;
	private String emailadv;
	private int idUser;
	private int idadministrator;
	private int idcostumer;
	private int idroles;
	private int fk_advisor_user;
	
	public int getIdadvisor() {
		return idadvisor;
	}
	public void setIdadvisor(int idadvisor) {
		this.idadvisor = idadvisor;
	}
	public String getIdentificationadv() {
		return identificationadv;
	}
	public void setIdentificationadv(String identificationadv) {
		this.identificationadv = identificationadv;
	}
		public String getPhoneadv() {
		return phoneadv;
	}
	public void setPhoneadv(String phoneadv) {
		this.phoneadv = phoneadv;
	}
	public String getFirstnameadv() {
		return firstnameadv;
	}
	public void setFirstnameadv(String firstnameadv) {
		this.firstnameadv = firstnameadv;
	}
	public String getLastnameadv() {
		return lastnameadv;
	}
	public void setLastnameadv(String lastnameadv) {
		this.lastnameadv = lastnameadv;
	}
	public String getEmailadv() {
		return emailadv;
	}
	public void setEmailadv(String emailadv) {
		this.emailadv = emailadv;
	}
	public int getIdUser() {
		return idUser;
	}
	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}
	public int getIdadministrator() {
		return idadministrator;
	}
	public void setIdadministrator(int idadministrator) {
		this.idadministrator = idadministrator;
	}
	public int getIdcostumer() {
		return idcostumer;
	}
	public void setIdcostumer(int idcostumer) {
		this.idcostumer = idcostumer;
	}
	public int getIdroles() {
		return idroles;
	}
	public void setIdroles(int idroles) {
		this.idroles = idroles;
	}
	public int getFk_advisor_user() {
		return fk_advisor_user;
	}
	public void setFk_advisor_user(int fk_advisor_user) {
		this.fk_advisor_user = fk_advisor_user;
	}
	@Override
	public String toString() {
		return "Advisor [idadvisor=" + idadvisor + ", identificationadv=" + identificationadv + ", phoneadv=" + phoneadv + ", firstnameadv=" + firstnameadv + ", lastnameadv="
				+ lastnameadv + ", emailadv=" + emailadv + ", idUser=" + idUser + ", idadministrator=" + idadministrator
				+ ", idcostumer=" + idcostumer + ", idroles=" + idroles + ", fk_advisor_user=" + fk_advisor_user + "]";
	}
	
	
	

}
