package co.com.vass.bank.vo;

public class City {
	private int idcity;
	private String namecity;
	private int iddepartament;
	private String typecity;
	private int idcostumer;
	public int getIdcity() {
		return idcity;
	}
	public void setIdcity(int idcity) {
		this.idcity = idcity;
	}
	public String getNamecity() {
		return namecity;
	}
	public void setNamecity(String namecity) {
		this.namecity = namecity;
	}
	public int getIddepartament() {
		return iddepartament;
	}
	public void setIddepartament(int iddepartament) {
		this.iddepartament = iddepartament;
	}
	public String getTypecity() {
		return typecity;
	}
	public void setTypecity(String typecity) {
		this.typecity = typecity;
	}
	public int getIdcostumer() {
		return idcostumer;
	}
	public void setIdcostumer(int idcostumer) {
		this.idcostumer = idcostumer;
	}
	@Override
	public String toString() {
		return "City [idcity=" + idcity + ", namecity=" + namecity + ", iddepartament=" + iddepartament + ", typecity="
				+ typecity + ", idcostumer=" + idcostumer + "]";
	}
	
	

}
