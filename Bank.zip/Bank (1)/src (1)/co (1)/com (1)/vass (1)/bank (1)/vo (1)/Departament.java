package co.com.vass.bank.vo;

public class Departament {
	private int iddepartament;
	private String namedepart;
	private int idcostumer;
	private String typedepart;
	public int getIddepartament() {
		return iddepartament;
	}
	public void setIddepartament(int iddepartament) {
		this.iddepartament = iddepartament;
	}
	public String getNamedepart() {
		return namedepart;
	}
	public void setNamedepart(String namedepart) {
		this.namedepart = namedepart;
	}
	public int getIdcostumer() {
		return idcostumer;
	}
	public void setIdcostumer(int idcostumer) {
		this.idcostumer = idcostumer;
	}
	public String getTypedepart() {
		return typedepart;
	}
	public void setTypedepart(String typedepart) {
		this.typedepart = typedepart;
	}
	@Override
	public String toString() {
		return "Departament [iddepartament=" + iddepartament + ", namedepart=" + namedepart + ", idcostumer="
				+ idcostumer + ", typedepart=" + typedepart + "]";
	}
	
	
	
	

}
