package co.com.vass.bank.vo;

public class Roles {
	private int idroles;
	private String costumer;
	private String advisor;
	private String administrator;
	private int idadvisor;
	private int idcostumer;
	private int idUser;
	private int idadministrator;
	public int getIdroles() {
		return idroles;
	}
	public void setIdroles(int idroles) {
		this.idroles = idroles;
	}
	public String getCostumer() {
		return costumer;
	}
	public void setCostumer(String costumer) {
		this.costumer = costumer;
	}
	public String getAdvisor() {
		return advisor;
	}
	public void setAdvisor(String advisor) {
		this.advisor = advisor;
	}
	public String getAdministrator() {
		return administrator;
	}
	public void setAdministrator(String administrator) {
		this.administrator = administrator;
	}
	public int getIdadvisor() {
		return idadvisor;
	}
	public void setIdadvisor(int idadvisor) {
		this.idadvisor = idadvisor;
	}
	public int getIdcostumer() {
		return idcostumer;
	}
	public void setIdcostumer(int idcostumer) {
		this.idcostumer = idcostumer;
	}
	public int getIdUser() {
		return idUser;
	}
	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}
	public int getIdadministrator() {
		return idadministrator;
	}
	public void setIdadministrator(int idadministrator) {
		this.idadministrator = idadministrator;
	}
	@Override
	public String toString() {
		return "Roles [idroles=" + idroles + ", costumer=" + costumer + ", advisor=" + advisor + ", administrator="
				+ administrator + ", idadvisor=" + idadvisor + ", idcostumer=" + idcostumer + ", idUser=" + idUser
				+ ", idadministrator=" + idadministrator + "]";
	}
	

}
